<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$company_id = $_GET['r_id'];

$result = "DELETE from company_details WHERE company_id = '$company_id'";
if (mysql_query($result)) {
    ?>
    <script type="text/javascript">
        window.location.href = 'internship_company_list.php';
    </script>
    <?php

} else {
    ?>
    <script type="text/javascript">
        alert('Could not delete data');
        window.location.href = 'internship_company_list.php';
    </script>
    <?php

}
?>
