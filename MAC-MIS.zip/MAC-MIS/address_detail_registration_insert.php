<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) { // Has the image been uploaded?
    $current_address = $_POST['current_address'];
    $current_city = $_POST['current_city'];
    $current_province = $_POST['current_province'];
    $current_country = $_POST['current_country'];
    $mailing_address = $_POST['mailing_address'];
    $mailing_city = $_POST['mailing_city'];
    $mailing_state = $_POST['mailing_state'];
    $mailing_country = $_POST['mailing_country'];
    $student_id = $_POST['student_id'];


    $result = $db->insertStudentAddressData($current_address, $current_city, $current_province, $current_country, $mailing_address, $mailing_city, $mailing_state, $mailing_country, $student_id);

    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'address_detail_list.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while inserting your data');
        </script>
        <?php

    }
}


if (isset($_POST['btn-update'])) { // Has the image been uploaded?
    $address_id = $_POST['address_id'];
    $current_address = $_POST['current_address'];
    $current_city = $_POST['current_city'];
    $current_province = $_POST['current_province'];
    $current_country = $_POST['current_country'];
    $mailing_address = $_POST['mailing_address'];
    $mailing_city = $_POST['mailing_city'];
    $mailing_state = $_POST['mailing_state'];
    $mailing_country = $_POST['mailing_country'];
    $student_id = $_POST['student_id'];

    $result = $db->updateStudentAddressData($current_address, $current_city, $current_province, $current_country, $mailing_address, $mailing_city, $mailing_state, $mailing_country, $student_id, $address_id);

    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'address_detail_list.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while updating your data');
        </script>
        <?php

    }
}
?>


