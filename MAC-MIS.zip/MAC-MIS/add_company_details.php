<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Company Registration</title>

		<meta name="description" content="and Validation" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/select2.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
		<link rel="stylesheet" href="assets/css/ace-skins.min.css" />
		<link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
		<script src="assets/js/ace-extra.min.js"></script>

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
	</head>

	<body class="no-skin">
            
            <!-- Main navbar -->
                <?php include 'header.php'; ?>
            <!-- /main navbar -->	

		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Home</a>
							</li>
							<li class="active">Internship</li>
							<li class="active">Company Details</li>
							<li class="active">Company Registration</li>
							
						</ul><!-- /.breadcrumb -->

						
					</div>

					<div class="page-content">
						

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								

								

								<div class="widget-box">
									<div class="widget-header widget-header-blue widget-header-flat">
										<h4 class="widget-title lighter">Add Company Detail</h4>


									</div>

									<div class="widget-body">
										<div class="widget-main">
											<div id="fuelux-wizard-container">
												

												<div class="step-content pos-rel">
													<div class="step-pane active" data-step="1">
														<h3 class="lighter block green">Enter the following information</h3>

                                                                                                                

														<form class="form-horizontal" id="validation-form" method="get">
                                                                                                                    
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="name">Address:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="text" id="name" name="name" class="col-xs-12 col-sm-5" />
																	</div>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                    
                                                                                                                    
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="state">Country</label>

																<div class="col-xs-12 col-sm-9">
																	<select id="state" name="state" class="select2" data-placeholder="Click to Choose...">
																		<option value="">&nbsp;</option>
																		<option value="AF">Afghanistan</option>
                                                                                                                                                <option value="AX">Åland Islands</option>
                                                                                                                                                <option value="AL">Albania</option>
                                                                                                                                                <option value="DZ">Algeria</option>
                                                                                                                                                <option value="AS">American Samoa</option>
                                                                                                                                                <option value="AD">Andorra</option>
                                                                                                                                                <option value="AO">Angola</option>
                                                                                                                                                <option value="AI">Anguilla</option>
                                                                                                                                                <option value="AQ">Antarctica</option>
                                                                                                                                                <option value="AG">Antigua and Barbuda</option>
                                                                                                                                                <option value="AR">Argentina</option>
                                                                                                                                                <option value="AM">Armenia</option>
                                                                                                                                                <option value="AW">Aruba</option>
                                                                                                                                                <option value="AU">Australia</option>
                                                                                                                                                <option value="AT">Austria</option>
                                                                                                                                                <option value="AZ">Azerbaijan</option>
                                                                                                                                                <option value="BS">Bahamas</option>
                                                                                                                                                <option value="BH">Bahrain</option>
                                                                                                                                                <option value="BD">Bangladesh</option>
                                                                                                                                                <option value="BB">Barbados</option>
                                                                                                                                                <option value="BY">Belarus</option>
                                                                                                                                                <option value="BE">Belgium</option>
                                                                                                                                                <option value="BZ">Belize</option>
                                                                                                                                                <option value="BJ">Benin</option>
                                                                                                                                                <option value="BM">Bermuda</option>
                                                                                                                                                <option value="BT">Bhutan</option>
                                                                                                                                                <option value="BO">Bolivia, Plurinational State of</option>
                                                                                                                                                <option value="BQ">Bonaire, Sint Eustatius and Saba</option>
                                                                                                                                                <option value="BA">Bosnia and Herzegovina</option>
                                                                                                                                                <option value="BW">Botswana</option>
                                                                                                                                                <option value="BV">Bouvet Island</option>
                                                                                                                                                <option value="BR">Brazil</option>
                                                                                                                                                <option value="IO">British Indian Ocean Territory</option>
                                                                                                                                                <option value="BN">Brunei Darussalam</option>
                                                                                                                                                <option value="BG">Bulgaria</option>
                                                                                                                                                <option value="BF">Burkina Faso</option>
                                                                                                                                                <option value="BI">Burundi</option>
                                                                                                                                                <option value="KH">Cambodia</option>
                                                                                                                                                <option value="CM">Cameroon</option>
                                                                                                                                                <option value="CA">Canada</option>
                                                                                                                                                <option value="CV">Cape Verde</option>
                                                                                                                                                <option value="KY">Cayman Islands</option>
                                                                                                                                                <option value="CF">Central African Republic</option>
                                                                                                                                                <option value="TD">Chad</option>
                                                                                                                                                <option value="CL">Chile</option>
                                                                                                                                                <option value="CN">China</option>
                                                                                                                                                <option value="CX">Christmas Island</option>
                                                                                                                                                <option value="CC">Cocos (Keeling) Islands</option>
                                                                                                                                                <option value="CO">Colombia</option>
                                                                                                                                                <option value="KM">Comoros</option>
                                                                                                                                                <option value="CG">Congo</option>
                                                                                                                                                <option value="CD">Congo, the Democratic Republic of the</option>
                                                                                                                                                <option value="CK">Cook Islands</option>
                                                                                                                                                <option value="CR">Costa Rica</option>
                                                                                                                                                <option value="CI">Côte d'Ivoire</option>
                                                                                                                                                <option value="HR">Croatia</option>
                                                                                                                                                <option value="CU">Cuba</option>
                                                                                                                                                <option value="CW">Curaçao</option>
                                                                                                                                                <option value="CY">Cyprus</option>
                                                                                                                                                <option value="CZ">Czech Republic</option>
                                                                                                                                                <option value="DK">Denmark</option>
                                                                                                                                                <option value="DJ">Djibouti</option>
                                                                                                                                                <option value="DM">Dominica</option>
                                                                                                                                                <option value="DO">Dominican Republic</option>
                                                                                                                                                <option value="EC">Ecuador</option>
                                                                                                                                                <option value="EG">Egypt</option>
                                                                                                                                                <option value="SV">El Salvador</option>
                                                                                                                                                <option value="GQ">Equatorial Guinea</option>
                                                                                                                                                <option value="ER">Eritrea</option>
                                                                                                                                                <option value="EE">Estonia</option>
                                                                                                                                                <option value="ET">Ethiopia</option>
                                                                                                                                                <option value="FK">Falkland Islands (Malvinas)</option>
                                                                                                                                                <option value="FO">Faroe Islands</option>
                                                                                                                                                <option value="FJ">Fiji</option>
                                                                                                                                                <option value="FI">Finland</option>
                                                                                                                                                <option value="FR">France</option>
                                                                                                                                                <option value="GF">French Guiana</option>
                                                                                                                                                <option value="PF">French Polynesia</option>
                                                                                                                                                <option value="TF">French Southern Territories</option>
                                                                                                                                                <option value="GA">Gabon</option>
                                                                                                                                                <option value="GM">Gambia</option>
                                                                                                                                                <option value="GE">Georgia</option>
                                                                                                                                                <option value="DE">Germany</option>
                                                                                                                                                <option value="GH">Ghana</option>
                                                                                                                                                <option value="GI">Gibraltar</option>
                                                                                                                                                <option value="GR">Greece</option>
                                                                                                                                                <option value="GL">Greenland</option>
                                                                                                                                                <option value="GD">Grenada</option>
                                                                                                                                                <option value="GP">Guadeloupe</option>
                                                                                                                                                <option value="GU">Guam</option>
                                                                                                                                                <option value="GT">Guatemala</option>
                                                                                                                                                <option value="GG">Guernsey</option>
                                                                                                                                                <option value="GN">Guinea</option>
                                                                                                                                                <option value="GW">Guinea-Bissau</option>
                                                                                                                                                <option value="GY">Guyana</option>
                                                                                                                                                <option value="HT">Haiti</option>
                                                                                                                                                <option value="HM">Heard Island and McDonald Islands</option>
                                                                                                                                                <option value="VA">Holy See (Vatican City State)</option>
                                                                                                                                                <option value="HN">Honduras</option>
                                                                                                                                                <option value="HK">Hong Kong</option>
                                                                                                                                                <option value="HU">Hungary</option>
                                                                                                                                                <option value="IS">Iceland</option>
                                                                                                                                                <option value="IN">India</option>
                                                                                                                                                <option value="ID">Indonesia</option>
                                                                                                                                                <option value="IR">Iran, Islamic Republic of</option>
                                                                                                                                                <option value="IQ">Iraq</option>
                                                                                                                                                <option value="IE">Ireland</option>
                                                                                                                                                <option value="IM">Isle of Man</option>
                                                                                                                                                <option value="IL">Israel</option>
                                                                                                                                                <option value="IT">Italy</option>
                                                                                                                                                <option value="JM">Jamaica</option>
                                                                                                                                                <option value="JP">Japan</option>
                                                                                                                                                <option value="JE">Jersey</option>
                                                                                                                                                <option value="JO">Jordan</option>
                                                                                                                                                <option value="KZ">Kazakhstan</option>
                                                                                                                                                <option value="KE">Kenya</option>
                                                                                                                                                <option value="KI">Kiribati</option>
                                                                                                                                                <option value="KP">Korea, Democratic People's Republic of</option>
                                                                                                                                                <option value="KR">Korea, Republic of</option>
                                                                                                                                                <option value="KW">Kuwait</option>
                                                                                                                                                <option value="KG">Kyrgyzstan</option>
                                                                                                                                                <option value="LA">Lao People's Democratic Republic</option>
                                                                                                                                                <option value="LV">Latvia</option>
                                                                                                                                                <option value="LB">Lebanon</option>
                                                                                                                                                <option value="LS">Lesotho</option>
                                                                                                                                                <option value="LR">Liberia</option>
                                                                                                                                                <option value="LY">Libya</option>
                                                                                                                                                <option value="LI">Liechtenstein</option>
                                                                                                                                                <option value="LT">Lithuania</option>
                                                                                                                                                <option value="LU">Luxembourg</option>
                                                                                                                                                <option value="MO">Macao</option>
                                                                                                                                                <option value="MK">Macedonia, the former Yugoslav Republic of</option>
                                                                                                                                                <option value="MG">Madagascar</option>
                                                                                                                                                <option value="MW">Malawi</option>
                                                                                                                                                <option value="MY">Malaysia</option>
                                                                                                                                                <option value="MV">Maldives</option>
                                                                                                                                                <option value="ML">Mali</option>
                                                                                                                                                <option value="MT">Malta</option>
                                                                                                                                                <option value="MH">Marshall Islands</option>
                                                                                                                                                <option value="MQ">Martinique</option>
                                                                                                                                                <option value="MR">Mauritania</option>
                                                                                                                                                <option value="MU">Mauritius</option>
                                                                                                                                                <option value="YT">Mayotte</option>
                                                                                                                                                <option value="MX">Mexico</option>
                                                                                                                                                <option value="FM">Micronesia, Federated States of</option>
                                                                                                                                                <option value="MD">Moldova, Republic of</option>
                                                                                                                                                <option value="MC">Monaco</option>
                                                                                                                                                <option value="MN">Mongolia</option>
                                                                                                                                                <option value="ME">Montenegro</option>
                                                                                                                                                <option value="MS">Montserrat</option>
                                                                                                                                                <option value="MA">Morocco</option>
                                                                                                                                                <option value="MZ">Mozambique</option>
                                                                                                                                                <option value="MM">Myanmar</option>
                                                                                                                                                <option value="NA">Namibia</option>
                                                                                                                                                <option value="NR">Nauru</option>
                                                                                                                                                <option value="NP">Nepal</option>
                                                                                                                                                <option value="NL">Netherlands</option>
                                                                                                                                                <option value="NC">New Caledonia</option>
                                                                                                                                                <option value="NZ">New Zealand</option>
                                                                                                                                                <option value="NI">Nicaragua</option>
                                                                                                                                                <option value="NE">Niger</option>
                                                                                                                                                <option value="NG">Nigeria</option>
                                                                                                                                                <option value="NU">Niue</option>
                                                                                                                                                <option value="NF">Norfolk Island</option>
                                                                                                                                                <option value="MP">Northern Mariana Islands</option>
                                                                                                                                                <option value="NO">Norway</option>
                                                                                                                                                <option value="OM">Oman</option>
                                                                                                                                                <option value="PK">Pakistan</option>
                                                                                                                                                <option value="PW">Palau</option>
                                                                                                                                                <option value="PS">Palestinian Territory, Occupied</option>
                                                                                                                                                <option value="PA">Panama</option>
                                                                                                                                                <option value="PG">Papua New Guinea</option>
                                                                                                                                                <option value="PY">Paraguay</option>
                                                                                                                                                <option value="PE">Peru</option>
                                                                                                                                                <option value="PH">Philippines</option>
                                                                                                                                                <option value="PN">Pitcairn</option>
                                                                                                                                                <option value="PL">Poland</option>
                                                                                                                                                <option value="PT">Portugal</option>
                                                                                                                                                <option value="PR">Puerto Rico</option>
                                                                                                                                                <option value="QA">Qatar</option>
                                                                                                                                                <option value="RE">Réunion</option>
                                                                                                                                                <option value="RO">Romania</option>
                                                                                                                                                <option value="RU">Russian Federation</option>
                                                                                                                                                <option value="RW">Rwanda</option>
                                                                                                                                                <option value="BL">Saint Barthélemy</option>
                                                                                                                                                <option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
                                                                                                                                                <option value="KN">Saint Kitts and Nevis</option>
                                                                                                                                                <option value="LC">Saint Lucia</option>
                                                                                                                                                <option value="MF">Saint Martin (French part)</option>
                                                                                                                                                <option value="PM">Saint Pierre and Miquelon</option>
                                                                                                                                                <option value="VC">Saint Vincent and the Grenadines</option>
                                                                                                                                                <option value="WS">Samoa</option>
                                                                                                                                                <option value="SM">San Marino</option>
                                                                                                                                                <option value="ST">Sao Tome and Principe</option>
                                                                                                                                                <option value="SA">Saudi Arabia</option>
                                                                                                                                                <option value="SN">Senegal</option>
                                                                                                                                                <option value="RS">Serbia</option>
                                                                                                                                                <option value="SC">Seychelles</option>
                                                                                                                                                <option value="SL">Sierra Leone</option>
                                                                                                                                                <option value="SG">Singapore</option>
                                                                                                                                                <option value="SX">Sint Maarten (Dutch part)</option>
                                                                                                                                                <option value="SK">Slovakia</option>
                                                                                                                                                <option value="SI">Slovenia</option>
                                                                                                                                                <option value="SB">Solomon Islands</option>
                                                                                                                                                <option value="SO">Somalia</option>
                                                                                                                                                <option value="ZA">South Africa</option>
                                                                                                                                                <option value="GS">South Georgia and the South Sandwich Islands</option>
                                                                                                                                                <option value="SS">South Sudan</option>
                                                                                                                                                <option value="ES">Spain</option>
                                                                                                                                                <option value="LK">Sri Lanka</option>
                                                                                                                                                <option value="SD">Sudan</option>
                                                                                                                                                <option value="SR">Suriname</option>
                                                                                                                                                <option value="SJ">Svalbard and Jan Mayen</option>
                                                                                                                                                <option value="SZ">Swaziland</option>
                                                                                                                                                <option value="SE">Sweden</option>
                                                                                                                                                <option value="CH">Switzerland</option>
                                                                                                                                                <option value="SY">Syrian Arab Republic</option>
                                                                                                                                                <option value="TW">Taiwan, Province of China</option>
                                                                                                                                                <option value="TJ">Tajikistan</option>
                                                                                                                                                <option value="TZ">Tanzania, United Republic of</option>
                                                                                                                                                <option value="TH">Thailand</option>
                                                                                                                                                <option value="TL">Timor-Leste</option>
                                                                                                                                                <option value="TG">Togo</option>
                                                                                                                                                <option value="TK">Tokelau</option>
                                                                                                                                                <option value="TO">Tonga</option>
                                                                                                                                                <option value="TT">Trinidad and Tobago</option>
                                                                                                                                                <option value="TN">Tunisia</option>
                                                                                                                                                <option value="TR">Turkey</option>
                                                                                                                                                <option value="TM">Turkmenistan</option>
                                                                                                                                                <option value="TC">Turks and Caicos Islands</option>
                                                                                                                                                <option value="TV">Tuvalu</option>
                                                                                                                                                <option value="UG">Uganda</option>
                                                                                                                                                <option value="UA">Ukraine</option>
                                                                                                                                                <option value="AE">United Arab Emirates</option>
                                                                                                                                                <option value="GB">United Kingdom</option>
                                                                                                                                                <option value="US">United States</option>
                                                                                                                                                <option value="UM">United States Minor Outlying Islands</option>
                                                                                                                                                <option value="UY">Uruguay</option>
                                                                                                                                                <option value="UZ">Uzbekistan</option>
                                                                                                                                                <option value="VU">Vanuatu</option>
                                                                                                                                                <option value="VE">Venezuela, Bolivarian Republic of</option>
                                                                                                                                                <option value="VN">Viet Nam</option>
                                                                                                                                                <option value="VG">Virgin Islands, British</option>
                                                                                                                                                <option value="VI">Virgin Islands, U.S.</option>
                                                                                                                                                <option value="WF">Wallis and Futuna</option>
                                                                                                                                                <option value="EH">Western Sahara</option>
                                                                                                                                                <option value="YE">Yemen</option>
                                                                                                                                                <option value="ZM">Zambia</option>
                                                                                                                                                <option value="ZW">Zimbabwe</option>
                                                                                                                                        </select>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                    
															<div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="state">Province</label>

																<div class="col-xs-12 col-sm-9">
																	<select id="state" name="state" class="select2" data-placeholder="Click to Choose...">
																		<option value="">&nbsp;</option>
																		<option value="AB">Alberta</option>
                                                                                                                                                <option value="BC">British Columbia</option>
                                                                                                                                                <option value="MB">Manitoba</option>
                                                                                                                                                <option value="NB">New Brunswick</option>
                                                                                                                                                <option value="NL">Newfoundland and Labrador</option>
                                                                                                                                                <option value="NS">Nova Scotia</option>
                                                                                                                                                <option value="ON">Ontario</option>
                                                                                                                                                <option value="PE">Prince Edward Island</option>
                                                                                                                                                <option value="QC">Quebec</option>
                                                                                                                                                <option value="SK">Saskatchewan</option>
                                                                                                                                                <option value="NT">Northwest Territories</option>
                                                                                                                                                <option value="NU">Nunavut</option>
                                                                                                                                                <option value="YT">Yukon</option>	
                                                                                                                                        </select>
																</div>
															</div>
									
															<div class="space-2"></div>
                                                                                                                        
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="state">City</label>

																<div class="col-xs-12 col-sm-9">
																	<select id="state" name="state" class="select2" data-placeholder="Click to Choose...">
																		<option value="">&nbsp;</option>
																		<option value="AB">Alberta</option>
                                                                                                                                                <option value="BC">British Columbia</option>
                                                                                                                                                <option value="MB">Manitoba</option>
                                                                                                                                                <option value="NB">New Brunswick</option>
                                                                                                                                                <option value="NL">Newfoundland and Labrador</option>
                                                                                                                                                <option value="NS">Nova Scotia</option>
                                                                                                                                                <option value="ON">Ontario</option>
                                                                                                                                                <option value="PE">Prince Edward Island</option>
                                                                                                                                                <option value="QC">Quebec</option>
                                                                                                                                                <option value="SK">Saskatchewan</option>
                                                                                                                                                <option value="NT">Northwest Territories</option>
                                                                                                                                                <option value="NU">Nunavut</option>
                                                                                                                                                <option value="YT">Yukon</option>	
                                                                                                                                        </select>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                        
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="name">Postal Code:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="text" id="name" name="name" class="col-xs-12 col-sm-5" />
																	</div>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                    
                                                                                                                    
                                                                                                                    
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="name">Contact First Name:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="text" id="name" name="name" class="col-xs-12 col-sm-5" />
																	</div>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                    
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="name">Contact Last Name:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="text" id="name" name="name" class="col-xs-12 col-sm-5" />
																	</div>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                    
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="name">Contact Position:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="text" id="name" name="name" class="col-xs-12 col-sm-5" />
																	</div>
																</div>
															</div>
                                                                                                                    
                                                                                                                        <div class="space-2"></div>
                                                                                                                        
                                                                                                                        <div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="phone">Phone Number:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="input-group">
																		<span class="input-group-addon">
																			<i class="ace-icon fa fa-phone"></i>
																		</span>

																		<input type="tel" id="phone" name="phone" />
																	</div>
																</div>
															</div>

															<div class="space-2"></div>

                                                                                                                    
                                                                                                                        
															<div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="email">Email Address:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="email" name="email" id="email" class="col-xs-12 col-sm-6" />
																	</div>
																</div>
															</div>

															
													
																				
															<div class="space-2"></div>

															
															<div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="url">Website:</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<input type="url" id="url" name="url" class="col-xs-12 col-sm-8" />
																	</div>
																</div>
															</div>

									


															<div class="form-group">
																<label class="control-label col-xs-12 col-sm-3 no-padding-right" for="comment">Notes</label>

																<div class="col-xs-12 col-sm-9">
																	<div class="clearfix">
																		<textarea class="input-xlarge" name="comment" id="comment"></textarea>
																	</div>
																</div>
															</div>

															<div class="space-8"></div>

															<div class="form-group">
																<div class="col-xs-12 col-sm-4 col-sm-offset-3">
																	<label>
																		<input name="agree" id="agree" type="checkbox" class="ace" />
																		<span class="lbl"> I accept the policy</span>
																	</label>
																</div>
															</div>
														</form>
													</div>

													<div class="step-pane" data-step="2">
														<div>
															<div class="alert alert-success">
																<button type="button" class="close" data-dismiss="alert">
																	<i class="ace-icon fa fa-times"></i>
																</button>

																<strong>
																	<i class="ace-icon fa fa-check"></i>
																	Well done!
																</strong>

																You successfully read this important alert message.
																<br />
															</div>

															<div class="alert alert-danger">
																<button type="button" class="close" data-dismiss="alert">
																	<i class="ace-icon fa fa-times"></i>
																</button>

																<strong>
																	<i class="ace-icon fa fa-times"></i>
																	Oh snap!
																</strong>

																Change a few things up and try submitting again.
																<br />
															</div>

															<div class="alert alert-warning">
																<button type="button" class="close" data-dismiss="alert">
																	<i class="ace-icon fa fa-times"></i>
																</button>
																<strong>Warning!</strong>

																Best check yo self, you're not looking too good.
																<br />
															</div>

															<div class="alert alert-info">
																<button type="button" class="close" data-dismiss="alert">
																	<i class="ace-icon fa fa-times"></i>
																</button>
																<strong>Heads up!</strong>

																This alert needs your attention, but it's not super important.
																<br />
															</div>
														</div>
													</div>

													<div class="step-pane" data-step="3">
														<div class="center">
															<h3 class="blue lighter">This is step 3</h3>
														</div>
													</div>

													<div class="step-pane" data-step="4">
														<div class="center">
															<h3 class="green">Congrats!</h3>
															Your product is ready to ship! Click finish to continue!
														</div>
													</div>
												</div>
											</div>

											<hr />
											<div class="wizard-actions">
												<button class="btn btn-prev">
													<i class="ace-icon fa fa-arrow-left"></i>
													Prev
												</button>

												<button class="btn btn-success btn-next" data-last="Finish">
													Next
													<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
												</button>
											</div>
										</div><!-- /.widget-main -->
									</div><!-- /.widget-body -->
								</div>

								<div id="modal-wizard" class="modal">
									<div class="modal-dialog">
										<div class="modal-content">
											<div id="modal-wizard-container">
												<div class="modal-header">
													<ul class="steps">
														<li data-step="1" class="active">
															<span class="step">1</span>
															<span class="title">Validation states</span>
														</li>

														<li data-step="2">
															<span class="step">2</span>
															<span class="title">Alerts</span>
														</li>

														<li data-step="3">
															<span class="step">3</span>
															<span class="title">Payment Info</span>
														</li>

														<li data-step="4">
															<span class="step">4</span>
															<span class="title">Other Info</span>
														</li>
													</ul>
												</div>

												<div class="modal-body step-content">
													<div class="step-pane active" data-step="1">
														<div class="center">
															<h4 class="blue">Step 1</h4>
														</div>
													</div>

													<div class="step-pane" data-step="2">
														<div class="center">
															<h4 class="blue">Step 2</h4>
														</div>
													</div>

													<div class="step-pane" data-step="3">
														<div class="center">
															<h4 class="blue">Step 3</h4>
														</div>
													</div>

													<div class="step-pane" data-step="4">
														<div class="center">
															<h4 class="blue">Step 4</h4>
														</div>
													</div>
												</div>
											</div>

											<div class="modal-footer wizard-actions">
												<button class="btn btn-sm btn-prev">
													<i class="ace-icon fa fa-arrow-left"></i>
													Prev
												</button>

												<button class="btn btn-success btn-sm btn-next" data-last="Finish">
													Next
													<i class="ace-icon fa fa-arrow-right icon-on-right"></i>
												</button>

												<button class="btn btn-danger btn-sm pull-left" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Cancel
												</button>
											</div>
										</div>
									</div>
								</div><!-- PAGE CONTENT ENDS -->
                                                                
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			

			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="assets/js/jquery-2.1.4.min.js"></script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- page specific plugin scripts -->
		<script src="assets/js/wizard.min.js"></script>
		<script src="assets/js/jquery.validate.min.js"></script>
		<script src="assets/js/jquery-additional-methods.min.js"></script>
		<script src="assets/js/bootbox.js"></script>
		<script src="assets/js/jquery.maskedinput.min.js"></script>
		<script src="assets/js/select2.min.js"></script>

		<!-- ace scripts -->
		<script src="assets/js/ace-elements.min.js"></script>
		<script src="assets/js/ace.min.js"></script>

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
			
				$('[data-rel=tooltip]').tooltip();
			
				$('.select2').css('width','200px').select2({allowClear:true})
				.on('change', function(){
					$(this).closest('form').validate().element($(this));
				}); 
			
			
				var $validation = false;
				$('#fuelux-wizard-container')
				.ace_wizard({
					//step: 2 //optional argument. wizard will jump to step "2" at first
					//buttons: '.wizard-actions:eq(0)'
				})
				.on('actionclicked.fu.wizard' , function(e, info){
					if(info.step == 1 && $validation) {
						if(!$('#validation-form').valid()) e.preventDefault();
					}
				})
				//.on('changed.fu.wizard', function() {
				//})
				.on('finished.fu.wizard', function(e) {
					bootbox.dialog({
						message: "Thank you! Your information was successfully saved!", 
						buttons: {
							"success" : {
								"label" : "OK",
								"className" : "btn-sm btn-primary"
							}
						}
					});
				}).on('stepclick.fu.wizard', function(e){
					//e.preventDefault();//this will prevent clicking and selecting steps
				});
			
			
				//jump to a step
				/**
				var wizard = $('#fuelux-wizard-container').data('fu.wizard')
				wizard.currentStep = 3;
				wizard.setState();
				*/
			
				//determine selected step
				//wizard.selectedItem().step
			
			
			
				//hide or show the other form which requires validation
				//this is for demo only, you usullay want just one form in your application
				$('#skip-validation').removeAttr('checked').on('click', function(){
					$validation = this.checked;
					if(this.checked) {
						$('#sample-form').hide();
						$('#validation-form').removeClass('hide');
					}
					else {
						$('#validation-form').addClass('hide');
						$('#sample-form').show();
					}
				})
			
			
			
				//documentation : http://docs.jquery.com/Plugins/Validation/validate
			
			
				$.mask.definitions['~']='[+-]';
				$('#phone').mask('(999) 999-9999');
			
				jQuery.validator.addMethod("phone", function (value, element) {
					return this.optional(element) || /^\(\d{3}\) \d{3}\-\d{4}( x\d{1,6})?$/.test(value);
				}, "Enter a valid phone number.");
			
				$('#validation-form').validate({
					errorElement: 'div',
					errorClass: 'help-block',
					focusInvalid: false,
					ignore: "",
					rules: {
						email: {
							required: true,
							email:true
						},
						password: {
							required: true,
							minlength: 5
						},
						password2: {
							required: true,
							minlength: 5,
							equalTo: "#password"
						},
						name: {
							required: true
						},
						phone: {
							required: true,
							phone: 'required'
						},
						url: {
							required: true,
							url: true
						},
						comment: {
							required: true
						},
						state: {
							required: true
						},
						platform: {
							required: true
						},
						subscription: {
							required: true
						},
						gender: {
							required: true,
						},
						agree: {
							required: true,
						}
					},
			
					messages: {
						email: {
							required: "Please provide a valid email.",
							email: "Please provide a valid email."
						},
						password: {
							required: "Please specify a password.",
							minlength: "Please specify a secure password."
						},
						state: "Please choose state",
						subscription: "Please choose at least one option",
						gender: "Please choose gender",
						agree: "Please accept our policy"
					},
			
			
					highlight: function (e) {
						$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
					},
			
					success: function (e) {
						$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
						$(e).remove();
					},
			
					errorPlacement: function (error, element) {
						if(element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
							var controls = element.closest('div[class*="col-"]');
							if(controls.find(':checkbox,:radio').length > 1) controls.append(error);
							else error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
						}
						else if(element.is('.select2')) {
							error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
						}
						else if(element.is('.chosen-select')) {
							error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
						}
						else error.insertAfter(element.parent());
					},
			
					submitHandler: function (form) {
					},
					invalidHandler: function (form) {
					}
				});
			
				
				
				
				$('#modal-wizard-container').ace_wizard();
				$('#modal-wizard .wizard-actions .btn[data-dismiss=modal]').removeAttr('disabled');
				
				
				/**
				$('#date').datepicker({autoclose:true}).on('changeDate', function(ev) {
					$(this).closest('form').validate().element($(this));
				});
				
				$('#mychosen').chosen().on('change', function(ev) {
					$(this).closest('form').validate().element($(this));
				});
				*/
				
				
				$(document).one('ajaxloadstart.page', function(e) {
					//in ajax mode, remove remaining elements before leaving page
					$('[class*=select2]').remove();
				});
			})
		</script>
                
                <!-- Footer -->
                    <?php include 'footer.php'; ?>
                <!-- /footer -->

	</body>
</html>
