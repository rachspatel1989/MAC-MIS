<?php
include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$job_id = $_GET['r_id'];

$sql = mysql_query("DELETE from job_responsibilities WHERE job_id = '$job_id'");
$sql_user = mysql_query("DELETE from job_requirements WHERE job_id= '$job_id'");
$result = "DELETE from job_details WHERE job_id = '$job_id'";
if (mysql_query($result)) {
    ?>
    <script type="text/javascript">
        alert('Data Deleted');
        window.location.href = 'internship_jobs.php';
    </script>
    <?php

} else {
    ?>
    <script type="text/javascript">
        alert('Could not delete data');
        window.location.href = 'internship_jobs.php';
    </script>
    <?php

}
?>
