<?php
include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) { // Has the image been uploaded?
    $job_group_description = $_POST['job_group_description'];

    $result = $db->insertJobGroupData($job_group_description);
    
    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'internship_job_groups.php';
        </script>
        <?php
    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while inserting your data');
        </script>
        <?php
    }
}

?>


