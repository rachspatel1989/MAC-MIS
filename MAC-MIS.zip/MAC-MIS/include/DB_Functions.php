<?php

include_once 'Config.php';

class DB_Functions {

    private $conn;

    public function __construct() {
        $db = new DB_Class();
    }

    function __destruct() {
        
    }

    function runQuery($query) {
        $result = mysql_query($query);
        while ($row = mysql_fetch_assoc($result)) {
            $resultset[] = $row;
        }
        if (!empty($resultset))
            return $resultset;
    }

    function numRows($query) {
        $result = mysql_query($query);
        $rowcount = mysql_num_rows($result);
        return $rowcount;
    }

    public function get_session() {
        return $_SESSION['log_id'];
    }

    public function user_logout() {
        $_SESSION['log_id'] = FALSE;
        session_destroy();
    }

    public function check_login($email, $password) {
        //$password = md5($password);
        $result = mysql_query("SELECT * from user WHERE user_email = '$email' and user_password = '$password'");
        $user_data = mysql_fetch_array($result);
        $no_rows = mysql_num_rows($result);

        if ($no_rows == 1) {
            $_SESSION['log_id'] = true;
            $_SESSION['login_id'] = $user_data['user_id'];
            $_SESSION['login_type'] = $user_data['user_type_id'];
            return TRUE;
        } else {
            echo "<script language='javascript' type='text/javascript'> alert('Email or Password Invalid');</script>";
            return FALSE;
        }
    }

    public function insertStaffData($uname, $fname, $lname, $email, $pwd) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO user(user_fname,user_lname,user_name,user_email,user_password,user_type_id) VALUES('$fname','$lname','$uname','$email','$pwd','1')";
        return $result;
    }

    public function updateStaffData($uname, $fname, $lname, $email, $pwd, $userid) {
        mysql_query("SET NAMES utf8");
        $result = "update user set user_fname='$fname',user_lname='$lname',user_name='$uname',user_email = '$email' where user_id='$userid'";
        return $result;
    }

    public function insertFacultyData($uname, $fname, $lname, $email, $pwd) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO user(user_fname,user_lname,user_name,user_email,user_password,user_type_id) VALUES('$fname','$lname','$uname','$email','$pwd','2')";
        return $result;
    }

    public function updateFacultyData($uname, $fname, $lname, $email, $pwd, $userid) {
        mysql_query("SET NAMES utf8");
        $result = "update user set user_fname='$fname',user_lname='$lname',user_name='$uname',user_email = '$email' where user_id='$userid'";
        return $result;
    }

    public function insertStudentData($student_number, $student_fname, $student_mname, $student_lname, $student_uname, $student_email, $student_phone, $student_gender, $student_status, $student_current_past) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO student_details(student_number,student_fname,student_mname,student_lname,student_uname,student_email,student_phone,student_gender,student_status,student_current_past) VALUES('$student_number','$student_fname','$student_mname','$student_lname','$student_uname','$student_email','$student_phone','$student_gender','$student_status','$student_current_past')";
        return $result;
    }

    public function updateStudentData($student_number, $student_fname, $student_mname, $student_lname, $student_uname, $student_phone, $student_gender, $student_status, $student_current_past, $student_id) {
        mysql_query("SET NAMES utf8");
        $result = "Update student_details set student_number= '$student_number',student_fname= '$student_fname',student_mname= '$student_mname',student_lname= '$student_lname',student_uname= '$student_uname',student_phone= '$student_phone',student_gender= '$student_gender',student_status= '$student_status',student_current_past= '$student_current_past' where student_id= '$student_id'";
        return $result;
    }

    public function insertEducationData($student_id, $degree_name, $degree_title, $degree_cgpa, $degree_university, $degree_university_location, $degree_start_month_year, $degree_end_month_year,$degree_status) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO education_details(degree_name,degree_title,degree_cgpa,degree_university,degree_university_location,degree_start_month_year,degree_end_month_year,degree_status,student_id) VALUES('$degree_name','$degree_title','$degree_cgpa','$degree_university','$degree_university_location','$degree_start_month_year','$degree_end_month_year','$degree_status','$student_id')";
        return $result;
    }

    public function updateEducationData($degree_id, $degree_name, $degree_title, $degree_cgpa, $degree_university, $degree_university_location, $degree_start_month_year, $degree_end_month_year,$degree_status) {
        mysql_query("SET NAMES utf8");
        $result = "Update education_details set degree_name= '$degree_name',degree_title= '$degree_title',degree_cgpa= '$degree_cgpa',degree_university= '$degree_university',degree_university_location= '$degree_university_location',degree_start_month_year= '$degree_start_month_year',degree_end_month_year= '$degree_end_month_year',degree_status= '$degree_status' where degree_id= '$degree_id'";
        return $result;
    }

    public function insertJobGroupData($job_group_description) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO job_groups(job_group_description) VALUES('$job_group_description')";
        return $result;
    }

    public function insertCompanyData($company_name, $company_address, $company_city, $company_province, $company_postalcode, $company_country, $company_contact_fname, $company_contact_lname, $company_contact_position, $company_phone, $company_email, $company_website, $company_notes) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO company_details(company_name,company_address,company_city,company_province,company_postalcode,company_country,company_contact_fname,company_contact_lname,company_contact_position,company_phone,company_email,company_website,company_notes) VALUES('$company_name','$company_address','$company_city','$company_province','$company_postalcode','$company_country','$company_contact_fname','$company_contact_lname','$company_contact_position','$company_phone','$company_email','$company_website','$company_notes')";
        return $result;
    }
    
    public function updateCompanyData($company_id,$company_name, $company_address, $company_city, $company_province, $company_postalcode, $company_country, $company_contact_fname, $company_contact_lname, $company_contact_position, $company_phone, $company_email, $company_website, $company_notes) {
        mysql_query("SET NAMES utf8");
        $result = "Update company_details set company_name= '$company_name',company_address= '$company_address',company_city= '$company_city',company_province= '$company_province',company_postalcode= '$company_postalcode',company_country= '$company_country',company_contact_fname= '$company_contact_fname',company_contact_lname= '$company_contact_lname',company_contact_position= '$company_contact_position',company_phone= '$company_phone',company_email= '$company_email',company_website= '$company_website',company_notes= '$company_notes' where company_id= '$company_id'";
        return $result;
    }
    
    public function insertstudentjobData($student_id, $job_status, $job_id) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO student_internship_details(job_id,student_id,`status`) VALUES('$job_id','$student_id','$job_status')";
        return $result;
    }
    
    public function insertStudentAddressData($current_address, $current_city, $current_province, $current_country, $mailing_address, $mailing_city, $mailing_state, $mailing_country, $student_id) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO address_details(current_address, current_city, current_province, current_country, mailing_address, mailing_city, mailing_state, mailing_country, student_id) VALUES('$current_address', '$current_city', '$current_province', '$current_country', '$mailing_address', '$mailing_city', '$mailing_state', '$mailing_country', '$student_id')";
        return $result;
    }
    
    public function updateStudentAddressData($current_address, $current_city, $current_province, $current_country, $mailing_address, $mailing_city, $mailing_state, $mailing_country, $student_id, $address_id) {
        mysql_query("SET NAMES utf8");
        $result = "Update address_details set current_address= '$current_address',current_city= '$current_city',current_province= '$current_province', current_country= '$current_country',mailing_address= '$mailing_address',mailing_city= '$mailing_city',mailing_state= '$mailing_state',mailing_country= '$mailing_country',student_id= '$student_id' where address_id= '$address_id'";
        return $result;
    }
    
    public function insertJobData($job_grp, $job_cmp, $job_intType,$job_position,$job_description,$job_salary, $job_status) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO job_details(job_group_id,job_company_id,job_internship_type_id,job_position,job_description,job_salary,job_status) VALUES('$job_grp','$job_cmp','$job_intType','$job_position','$job_description','$job_salary','$job_status')"; 
        return $result;
    }
    
    public function updateJobData($job_grp, $job_cmp, $job_intType,$job_position,$job_description,$job_salary, $job_status, $job_id) {
        mysql_query("SET NAMES utf8");
        $result = "Update job_details set job_group_id= '$job_grp',job_company_id= '$job_cmp',job_internship_type_id= '$job_intType',job_position= '$job_position',job_description= '$job_description',job_salary= '$job_salary',job_status= '$job_status' where job_id= '$job_id'"; 
        return $result;
    }
    
    public function insertJobResponsibility($job_resp,$max_job_id) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO job_responsibilities(job_resp_desc,job_id) VALUES('$job_resp','$max_job_id')";
        return $result;
    }
    
    public function insertJobRequirements($job_req,$max_job_id) {
        mysql_query("SET NAMES utf8");
        $result = "INSERT INTO job_requirements(job_req_desc,job_id) VALUES('$job_req','$max_job_id')";
        return $result;
    }
    
    public function updateJobResponsibility($job_resp,$job_id) {
        mysql_query("SET NAMES utf8");
        $result = "Update job_responsibilities set job_resp_desc= '$job_resp' where job_id= '$job_id'";
        return $result;
    }
    
    public function updateJobRequirements($job_req,$job_id) {
        mysql_query("SET NAMES utf8");
        $result = "Update job_requirements set job_req_desc= '$job_req' where job_id= '$job_id'";
        return $result;
    }
    
    public function isStudentExisted($student_email) {
        mysql_query("SET NAMES utf8");
        $result = mysql_query("SELECT student_email FROM student_details where student_email = '$student_email'");
        $no_rows_res = mysql_num_rows($result);
        if ($no_rows_res == 1) {
            return $student_email;
        } else {
            return FALSE;
        }
    }

    public function isUserExisted($email) {
        mysql_query("SET NAMES utf8");
        $result = mysql_query("SELECT user_email FROM user where user_email = '$email'");
        $no_rows_res = mysql_num_rows($result);
        if ($no_rows_res == 1) {
            return $email;
        } else {
            return FALSE;
        }
    }
}
