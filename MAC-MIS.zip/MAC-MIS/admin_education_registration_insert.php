<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) { // Has the image been uploaded?
    $student_id = $_POST['student_id'];
    $degree_name = $_POST['degree_name'];
    $degree_title = $_POST['degree_title'];
    $degree_cgpa = $_POST['degree_cgpa'];
    $degree_university = $_POST['degree_university'];
    $degree_university_location = $_POST['degree_university_location'];
    $degree_start_month_year = $_POST['degree_start_month_year'];
    $degree_end_month_year = $_POST['degree_end_month_year'];
    $degree_status = $_POST['degree_status'];
    $certi_title = $_POST['certi_title'];
    $certi_body = $_POST['certi_body'];

    $result = $db->insertEducationData($student_id, $degree_name, $degree_title, $degree_cgpa, $degree_university, $degree_university_location, $degree_start_month_year, $degree_end_month_year,$degree_status);
    mysql_query($result);
    $sql_fetch = "SELECT max(degree_id) as degree_id FROM education_details where student_id = '$student_id'";
    if (!( $selectRes = mysql_query($sql_fetch) )) {
        echo 'Retrieval of data from Database Failed - #' . mysql_errno() . ': ' . mysql_error();
    } else {
        if (mysql_num_rows($selectRes) == 0) {
            echo 'No Rows Returned';
        } else {
            
        }
        while ($row = mysql_fetch_assoc($selectRes)) {
            $degree_id = $row['degree_id'];
            $sql = "INSERT INTO certification_details(certi_title,certi_body,degree_id) VALUES('" . implode(", ", $certi_title) . "','" . implode(", ", $certi_body) . "','$degree_id')";
            if (mysql_query($sql)) {
                ?>
                <script type="text/javascript">
                    window.location.href = 'admin_education_list.php';
                </script>
                <?php

            } else {
                ?>
                <script type="text/javascript">
                    alert('error occured while inserting your data');
                </script>
                <?php

            }
        }
    }
}

if (isset($_POST['btn-update'])) { // Has the image been uploaded?
    $degree_id = $_POST['degree_id'];
    $degree_name = $_POST['degree_name'];
    $degree_title = $_POST['degree_title'];
    $degree_cgpa = $_POST['degree_cgpa'];
    $degree_university = $_POST['degree_university'];
    $degree_university_location = $_POST['degree_university_location'];
    $degree_start_month_year = $_POST['degree_start_month_year'];
    $degree_end_month_year = $_POST['degree_end_month_year'];
    $degree_status = $_POST['degree_status'];
    $certi_title = $_POST['certi_title'];
    $certi_body = $_POST['certi_body'];
    $student_id = $_POST['student_id'];

    $result = $db->updateEducationData($degree_id, $degree_name, $degree_title, $degree_cgpa, $degree_university, $degree_university_location, $degree_start_month_year, $degree_end_month_year,$degree_status);
    mysql_query($result);
    $sql = "Update certification_details set certi_title= '" . implode(", ", $certi_title) . "',certi_body= '" . implode(", ", $certi_body) . "' where degree_id= '$degree_id'";
    if (mysql_query($sql)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'admin_education_details.php?r_id=<?php echo $student_id ?>';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while updating your data');
        </script>
        <?php

    }
}
?>


