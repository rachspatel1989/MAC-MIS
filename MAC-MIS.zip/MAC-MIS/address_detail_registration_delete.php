<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$address_id = $_GET['r_id'];

$sql = mysql_query("DELETE from address_details WHERE address_id = '$address_id'");

if ($sql) {
    ?>
    <script type="text/javascript">
        alert("Deleted data successfully");
        window.location.href = 'address_detail_list.php';
    </script>
    <?php

} else {
    ?>
    <script type="text/javascript">
        alert('Could not delete data');
        window.location.href = 'address_detail_list.php';
    </script>
    <?php

}
?>
